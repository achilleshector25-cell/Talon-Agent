def test_owner_flag_not_client_controlled():
    from talon.gateway.mtls import Identity
    # Identity must be server-derived
    ident = Identity(spiffe_id="spiffe://talon/owner/test", role="owner", channel="telegram", fingerprint="abc", is_owner=True)
    assert ident.is_owner is True
    # No way to set via request payload

def test_policy_default_deny():
    from talon.gateway.policy_engine import PolicyEngine
    from talon.gateway.mtls import Identity
    pe = PolicyEngine()
    guest = Identity(spiffe_id="spiffe://talon/guest/x", role="guest", channel="telegram", fingerprint="xyz", is_owner=False)
    assert pe.evaluate(guest, "shell", {"cmd":"rm -rf /"}) is False
    assert pe.evaluate(guest, "web_search", {}) is True
