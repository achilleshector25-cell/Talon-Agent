"""Orchestrator — ReAct with verification"""
import asyncio
from .taint_graph import TaintGraph
from .guardrails import Guardrail
from .token_budget import TokenBucket
from ..tools.registry import ToolRegistry

class Orchestrator:
    def __init__(self, memory, policy_engine):
        self.memory = memory
        self.policy = policy_engine
        self.taint = TaintGraph()
        self.guard = Guardrail()
        self.budget = TokenBucket()
        self.tools = ToolRegistry()

    async def run(self, message: str, identity, channel: str, client_ip: str):
        # 1. Taint incoming message
        node = self.taint.add_content(message, source=f"{channel}:untrusted_user", trust=0.0 if not identity.is_owner else 0.9)
        # 2. Guardrail scan
        scan = self.guard.scan(message)
        if scan["blocked"]:
            return {"error":"blocked_by_guardrail","hits":scan["hits"],"taint":node.id}

        # 3. Token budget check
        est = self.budget.estimate(message)
        if not self.budget.consume(est):
            return {"error":"token_budget_exhausted","remaining":self.budget.remaining}

        # 4. Check cache
        cache_key = f"{identity.spiffe_id}:{hash(message)}"
        cached = self.budget.get_cached(cache_key)
        if cached:
            return {"cached":True, **cached}

        # 5. Plan (in prod: LLM call with taint-rendered prompt)
        rendered = self.taint.render_for_llm(message, node)
        # Simulated planning — in prod calls Claude/LLM with structured output
        plan = self._mock_plan(message, identity)

        # 6. Verification + policy + execution
        results = []
        for step in plan:
            tool = step["tool"]
            args = step["args"]
            if not self.policy.evaluate(identity, tool, args):
                results.append({"tool":tool,"error":"policy_denied"})
                continue
            # Execute in sandbox
            out = await self.tools.execute(tool, args, identity)
            results.append(out)

        final = {"message":message,"plan":plan,"results":results,"taint_graph":len(self.taint.nodes),"identity":identity.spiffe_id}
        self.budget.set_cached(cache_key, final)
        # 7. Episodic memory append (encrypted)
        await self.memory.append_episodic(final)
        return final

    def _mock_plan(self, msg: str, ident):
        msg_l = msg.lower()
        if "read" in msg_l or "file" in msg_l:
            return [{"tool":"file_read","args":{"path":"/workspace/README.md"}}]
        if "search" in msg_l:
            return [{"tool":"web_search","args":{"query":msg[:100]}}]
        if "shell" in msg_l or "run" in msg_l:
            return [{"tool":"shell","args":{"cmd":"ls -la","approved": ident.is_owner}}]
        return [{"tool":"web_search","args":{"query":msg[:80]}}]
