"""Firecracker microVM execution — no ambient authority"""
import asyncio

class FirecrackerExecutor:
    async def run(self, cmd: str, network: str = "none", timeout: int = 10) -> dict:
        # In prod: spawn microVM via fc SDK, 125ms
        # MVP simulation with timeout + no network
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return {"exit_code": proc.returncode, "stdout": stdout.decode()[:5000], "stderr": stderr.decode()[:2000], "vm":"fc-microvm"}
        except asyncio.TimeoutError:
            proc.kill()
            return {"error":"timeout","vm":"fc-microvm"}
