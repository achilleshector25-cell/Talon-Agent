"""Vault-backed token storage — 15m TTL, bound to fingerprint+IP"""
import os, time, secrets
from typing import Dict

class TokenVault:
    def __init__(self):
        self._store: Dict[str, dict] = {}

    def mint(self, identity, ip: str, ttl: int = 900) -> str:
        token = secrets.token_urlsafe(32)
        self._store[token] = {
            "spiffe": identity.spiffe_id,
            "fingerprint": identity.fingerprint,
            "ip": ip,
            "exp": time.time()+ttl,
            "role": identity.role,
            "is_owner": identity.is_owner,
        }
        return token

    def validate(self, token: str, fingerprint: str, ip: str):
        rec = self._store.get(token)
        if not rec: return None
        if time.time() > rec["exp"]: 
            del self._store[token]
            return None
        if rec["fingerprint"] != fingerprint: return None
        if rec["ip"] != ip: return None
        return rec

    def rotate_all(self):
        self._store.clear()
