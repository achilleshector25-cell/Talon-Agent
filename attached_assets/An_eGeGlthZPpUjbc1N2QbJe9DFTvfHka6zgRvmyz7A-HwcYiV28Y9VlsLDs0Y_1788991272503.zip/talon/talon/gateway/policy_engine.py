"""OPA-style policy engine — default deny, capability-based"""
from typing import Dict, Any
import time

class PolicyEngine:
    def __init__(self):
        # Rego compiled logically: default deny
        self.policies = [
            # owner can read files in workspace
            lambda ident, tool, args: ident.is_owner and tool=="file_read" and args.get("path","").startswith("/workspace"),
            # shell requires approval + owner + microVM
            lambda ident, tool, args: ident.is_owner and tool=="shell" and args.get("approved", False) is True,
            # guests can only use web_search
            lambda ident, tool, args: not ident.is_owner and tool=="web_search",
        ]

    def evaluate(self, identity, tool: str, args: Dict[str, Any]) -> bool:
        if identity.role == "system":
            return True
        for rule in self.policies:
            try:
                if rule(identity, tool, args):
                    return True
            except Exception:
                continue
        return False

    def audit(self, identity, tool, args, allowed: bool):
        return {
            "ts": time.time(),
            "spiffe": identity.spiffe_id,
            "tool": tool,
            "args_hash": hash(str(args)),
            "allowed": allowed,
            "fingerprint": identity.fingerprint,
        }
