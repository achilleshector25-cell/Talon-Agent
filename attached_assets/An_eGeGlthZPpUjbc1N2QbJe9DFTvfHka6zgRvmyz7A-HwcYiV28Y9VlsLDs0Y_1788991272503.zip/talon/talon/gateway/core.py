"""TALON Secure Gateway — FastAPI, QUIC-ready, mTLS enforced"""
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from pydantic import BaseModel
from .mtls import derive_identity_from_cert
from .policy_engine import PolicyEngine
from .token_vault import TokenVault
from ..runtime.orchestrator import Orchestrator
from ..memory.vault import MemoryVault
import os

app = FastAPI(title="TALON Gateway", version="1.0.0")
policy = PolicyEngine()
vault = TokenVault()
memory = MemoryVault()
orch = Orchestrator(memory=memory, policy_engine=policy)

class TaskRequest(BaseModel):
    message: str
    channel: str = "telegram"
    tool: str | None = None
    args: dict = {}

def get_identity(request: Request, x_client_cert: str = Header(None)):
    # In prod: nginx/envoy forwards client cert PEM. Here simulated.
    if not x_client_cert:
        # dev fallback: simulate owner cert
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        import datetime
        # For demo, create ephemeral identity
        class FakeIdent:
            spiffe_id="spiffe://talon/owner/dev"
            role="owner"
            channel="telegram"
            fingerprint="dev-fp"
            is_owner=True
        return FakeIdent()
    try:
        return derive_identity_from_cert(x_client_cert.encode(), "telegram")
    except Exception as e:
        raise HTTPException(401, f"Invalid client cert: {e}")

@app.post("/v1/task")
async def handle_task(req: TaskRequest, request: Request, ident=Depends(get_identity)):
    # Policy check if explicit tool requested
    if req.tool:
        allowed = policy.evaluate(ident, req.tool, req.args)
        audit = policy.audit(ident, req.tool, req.args, allowed)
        if not allowed:
            raise HTTPException(403, f"Denied by policy: {audit}")
    # Orchestrate via taint-aware runtime
    result = await orch.run(
        message=req.message,
        identity=ident,
        channel=req.channel,
        client_ip=request.client.host if request.client else "127.0.0.1"
    )
    return result

@app.post("/v1/lockdown")
async def lockdown(ident=Depends(get_identity)):
    if not ident.is_owner:
        raise HTTPException(403, "Owner only")
    vault.rotate_all()
    return {"status":"locked","vault_cleared":True}

@app.get("/health")
async def health():
    return {"status":"ok","version":"1.0.0","security":"mtls+policy+taint+microvm"}
