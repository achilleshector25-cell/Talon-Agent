"""mTLS + SPIFFE ID derivation — fixes CVE-2026-44118 (senderIsOwner trust)"""
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from dataclasses import dataclass
from typing import Literal

@dataclass(frozen=True)
class Identity:
    spiffe_id: str
    role: Literal["owner","guest","system"]
    channel: str
    fingerprint: str
    is_owner: bool  # SERVER-DERIVED, never client supplied

def derive_identity_from_cert(pem_bytes: bytes, channel: str) -> Identity:
    cert = x509.load_pem_x509_certificate(pem_bytes, default_backend())
    # SAN URI contains spiffe://talon/owner/<id> or spiffe://talon/guest/<id>
    san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    uris = san.get_values_for_type(x509.UniformResourceIdentifier)
    spiffe = next((u for u in uris if u.startswith("spiffe://talon/")), None)
    if not spiffe:
        raise ValueError("No SPIFFE ID in cert")
    role = "owner" if "/owner/" in spiffe else "guest"
    # fingerprint binding prevents token theft
    fingerprint = cert.fingerprint(cert.signature_hash_algorithm).hex()[:16]
    return Identity(
        spiffe_id=spiffe,
        role=role,
        channel=channel,
        fingerprint=fingerprint,
        is_owner=(role=="owner")
    )
