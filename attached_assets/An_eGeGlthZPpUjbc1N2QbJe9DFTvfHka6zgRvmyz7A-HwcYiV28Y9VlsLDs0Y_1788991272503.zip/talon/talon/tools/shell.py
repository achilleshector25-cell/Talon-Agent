class Tool:
    name="shell"
    async def run(self, args, identity, executor=None):
        cmd = args.get("cmd","echo hello")
        approved = args.get("approved", False)
        if not approved:
            return {"error":"shell requires approved=True and owner role"}
        if not identity.is_owner:
            return {"error":"owner only"}
        # Execute in Firecracker microVM, no network
        if executor:
            res = await executor.run(cmd, network="none", timeout=10)
            return {"tool":"shell","cmd":cmd, **res}
        return {"tool":"shell","cmd":cmd,"simulated":True}
