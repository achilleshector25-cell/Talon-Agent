from pathlib import Path

class Tool:
    name="file_read"
    async def run(self, args, identity, executor=None):
        path = args.get("path","/workspace/README.md")
        # Enforce workspace jail
        p = Path(path)
        if not str(p).startswith("/workspace") and not str(p).startswith("/mnt/data/talon"):
            return {"error":"path denied, must be /workspace or /mnt/data/talon"}
        try:
            # gVisor in prod
            content = Path("/mnt/data/talon/README.md").read_text()[:5000] if not Path(path).exists() else Path(path).read_text()[:5000]
            return {"tool":"file_read","path":path,"content":content[:2000]}
        except Exception as e:
            return {"error":str(e)}
